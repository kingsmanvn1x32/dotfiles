// ==UserScript==
// @name        Stylus Stylish
// @namespace   Stylus Stylish Userscript - Violentmonkey Scripts
// @include       *://*/*
// @grant       GM_addStyle
// @version     1.0
// @run-at      document-start
// @author      -
// @description -
// ==/UserScript==

GM_addStyle(`
  svg, button, input, span, body {
    fill: auto!important;
  }

  input[type="checkbox"], input[type="radio"] {
    opacity: 1!important;
    z-index: 999!important;
    appearance: auto!important;
  }
`)
