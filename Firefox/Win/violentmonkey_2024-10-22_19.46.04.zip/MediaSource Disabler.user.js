// ==UserScript==
// @name            MediaSource Disabler
// @author          Your name
// @namespace       http://www.example.url/to/your-web-site/
// @description     Put a good description in here
// @license         Creative Commons Attribution License
// @version            0.1
// @include         http*://ok.ru/*
// @grant        unsafeWindow
// @run-at           document-start
// @released        2006-04-17
// @updated         2006-04-19
// @compatible      Greasemonkey
// ==/UserScript==

try{delete unsafeWindow.MediaSource}catche(e){}
try{delete window.MediaSource}catche(e){}
try{delete MediaSource}catche(e){}
